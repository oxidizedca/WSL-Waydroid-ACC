/* A failed recovery has no pixels to attach. Preserve the last committed
 * surface content and continue processing the vendor's commit and fences. */
struct hold_attach {
    struct wl_listener destroy;
    struct wl_list link;
    struct wl_client *client;
};
static struct wl_list holds;
static void remove_hold(struct wl_listener *listener,void *unused)
{
    struct hold_attach *h=wl_container_of(listener,h,destroy);
    wl_list_remove(&h->link);
    wl_list_remove(&h->destroy.link);
    free(h);
}
static void hold_carrier(struct wl_client *client,struct wl_resource *manager,struct wl_resource *carrier)
{
    if(wl_resource_get_destroy_listener(carrier,remove_hold)) return;
    struct hold_attach *h=calloc(1,sizeof(*h));
    if(!h) {wl_client_post_no_memory(client); return;}
    h->client=client;
    h->destroy.notify=remove_hold;
    wl_resource_add_destroy_listener(carrier,&h->destroy);
    wl_list_insert(&holds,&h->link);
}
static void clear_holds(struct wl_client *client)
{
    struct hold_attach *h,*next;
    wl_list_for_each_safe(h,next,&holds,link)
        if(h->client==client) remove_hold(&h->destroy,NULL);
}
