/* Included by the pinned Weston 14 gl-renderer. One immutable EGLImage per offer.
 * The desktop context owns the GL memory object only until EGL takes a reference. */
#include <libweston/plugin-registry.h>
#include "wd-server.h"
#include "wd-protocol.c"

static EGLContext t6_desktop;
static struct wl_global *t6_global;
struct t6_offer {
    EGLImageKHR image;
    EGLDisplay display;
    int width, height;
    bool opaque, physical;
    uint32_t serial;
    struct weston_buffer_reference hold;
    struct wl_listener carrier_gone;
    struct wl_resource *carrier, *resource;
    struct wl_list link;
};
static struct wl_list t6_pending;

static void t6_unlink(struct t6_offer *o)
{
    if (!o->carrier) return;
    wl_list_remove(&o->link);
    wl_list_remove(&o->carrier_gone.link);
    o->carrier = NULL;
}
static void t6_cancel(struct t6_offer *o)
{
    t6_unlink(o);
}
static void t6_carrier_gone(struct wl_listener *listener, void *unused)
{
    struct t6_offer *o = wl_container_of(listener, o, carrier_gone);
    t6_cancel(o);
}
static void t6_dispose(struct wl_resource *resource)
{
    struct t6_offer *o = wl_resource_get_user_data(resource);
    if (!o) return;
    t6_unlink(o);
    weston_buffer_reference(&o->hold,NULL,BUFFER_WILL_NOT_BE_ACCESSED);
    if (o->image) eglDestroyImage(o->display, o->image);
    free(o);
}
static void t6_destroy_buffer(struct wl_client *client, struct wl_resource *resource)
{
    wl_resource_destroy(resource);
}
static const struct wl_buffer_interface t6_buffer_impl = {t6_destroy_buffer};

static EGLImageKHR t6_import(struct gl_renderer *gr, int fd, int width, int height)
{
    EGLDisplay d = gr->egl_display;
    EGLContext saved = eglGetCurrentContext();
    EGLSurface draw = eglGetCurrentSurface(EGL_DRAW), read = eglGetCurrentSurface(EGL_READ);
    EGLenum api = eglQueryAPI();
    EGLImageKHR image = EGL_NO_IMAGE_KHR;
    GLuint memory = 0, texture = 0;
    GLint dedicated = GL_TRUE;
    PFNGLCREATEMEMORYOBJECTSEXTPROC create = (void *)eglGetProcAddress("glCreateMemoryObjectsEXT");
    PFNGLMEMORYOBJECTPARAMETERIVEXTPROC param = (void *)eglGetProcAddress("glMemoryObjectParameterivEXT");
    PFNGLIMPORTMEMORYFDEXTPROC import = (void *)eglGetProcAddress("glImportMemoryFdEXT");
    PFNGLTEXSTORAGEMEM2DEXTPROC storage = (void *)eglGetProcAddress("glTexStorageMem2DEXT");
    PFNGLDELETEMEMORYOBJECTSEXTPROC drop = (void *)eglGetProcAddress("glDeleteMemoryObjectsEXT");
    if (!create || !param || !import || !storage || !drop || !eglBindAPI(EGL_OPENGL_API))
        goto done;
    if (!t6_desktop) {
        EGLint n;
        EGLConfig cfg;
        const EGLint attrs[] = {EGL_RENDERABLE_TYPE,EGL_OPENGL_BIT,EGL_SURFACE_TYPE,EGL_PBUFFER_BIT,EGL_NONE};
        if (!eglChooseConfig(d, attrs, &cfg, 1, &n) || !n) goto restore;
        t6_desktop = eglCreateContext(d, cfg, EGL_NO_CONTEXT, NULL);
    }
    if (!t6_desktop || !eglMakeCurrent(d,EGL_NO_SURFACE,EGL_NO_SURFACE,t6_desktop)) goto restore;
    create(1,&memory);
    param(memory,GL_DEDICATED_MEMORY_OBJECT_EXT,&dedicated);
    import(memory,(uint64_t)width*height*4,GL_HANDLE_TYPE_OPAQUE_FD_EXT,fd);
    fd = -1;
    glGenTextures(1,&texture);
    glBindTexture(GL_TEXTURE_2D,texture);
    storage(GL_TEXTURE_2D,1,GL_RGBA8,width,height,memory,0);
    if (glGetError() == GL_NO_ERROR) {
        const EGLint attrs[] = {EGL_IMAGE_PRESERVED_KHR,EGL_TRUE,EGL_NONE};
        image = gr->create_image(d,t6_desktop,EGL_GL_TEXTURE_2D_KHR,(void *)(uintptr_t)texture,attrs);
    }
    glDeleteTextures(1,&texture);
    drop(1,&memory);
restore:
    eglBindAPI(api);
    if (!eglMakeCurrent(d,draw,read,saved) && image) {
        gr->destroy_image(d,image);
        image = EGL_NO_IMAGE_KHR;
    }
done:
    if (fd >= 0) close(fd);
    return image;
}

#include "hold.h"
static void t6_finish(struct wl_client *client, struct wl_resource *manager)
{
    clear_holds(client);
    struct t6_offer *o, *next;
    wl_list_for_each_safe(o,next,&t6_pending,link)
        if (wl_resource_get_client(o->resource) == client) t6_cancel(o);
}
static void import_offer(struct wl_client *client, struct wl_resource *manager, uint32_t id,
                     struct wl_resource *carrier, int fd, uint32_t opaque, uint32_t serial, int w, int h)
{
    struct weston_compositor *ec = wl_resource_get_user_data(manager);
    struct wl_resource *res = wl_resource_create(client,&wl_buffer_interface,1,id);
    struct t6_offer *o = calloc(1,sizeof(*o));
    if (!res || !o) { close(fd); free(o); wl_client_post_no_memory(client); return; }
    o->resource = res;
    o->serial = serial;
    wl_resource_set_implementation(res,&t6_buffer_impl,o,t6_dispose);
    struct wl_shm_buffer *shm = carrier ? wl_shm_buffer_get(carrier) : NULL;
    pid_t pid; uid_t uid; gid_t gid;
    wl_client_get_credentials(client,&pid,&uid,&gid);
    char link[64], name[80] = {0};
    snprintf(link,sizeof(link),"/proc/self/fd/%d",fd);
    ssize_t len = readlink(link,name,sizeof(name)-1);
    if (shm) {w=wl_shm_buffer_get_width(shm); h=wl_shm_buffer_get_height(shm);}
    if (uid == getuid() && ((carrier && w==1222 && h==1048) || (!carrier && w>0 && h>0 && w<=8192 && h<=8192)) &&
        (!carrier || wl_shm_buffer_get_height(shm)==1048) && opaque<=1 && len>0 &&
        strcmp(name,"anon_inode:dxgresource")==0) {
        o->display=get_renderer(ec)->egl_display;
        o->opaque=opaque; o->width=w; o->height=h; o->physical=!carrier;
        o->image=t6_import(get_renderer(ec),fd,w,h);
    } else close(fd);
    struct weston_buffer *wb = o->image ? weston_buffer_from_resource(ec,res) : NULL;
    bool ok = wb != NULL;
    if (ok) {
        /* Hold release across repeated attaches. Retire drops this reference;
         * the compositor drops its own once the final use has ended. */
        weston_buffer_reference(&o->hold,wb,BUFFER_MAY_BE_ACCESSED);
        o->carrier_gone.notify=t6_carrier_gone;
        if (!carrier) {
            wd_texture_manager_v1_send_result(manager,serial,1);
            return;
        }
        t6_finish(client,manager);
        o->carrier=carrier;
        o->carrier_gone.notify=t6_carrier_gone;
        wl_resource_add_destroy_listener(carrier,&o->carrier_gone);
        wl_list_insert(&t6_pending,&o->link);
    }
    wd_texture_manager_v1_send_result(manager,serial,ok);
}
static void t6_reuse(struct wl_client *client,struct wl_resource *manager,
                     struct wl_resource *res,struct wl_resource *carrier)
{
    if (!wl_resource_instance_of(res,&wl_buffer_interface,&t6_buffer_impl)) return;
    struct t6_offer *o=wl_resource_get_user_data(res);
    struct wl_shm_buffer *shm=wl_shm_buffer_get(carrier);
    if (!o || !o->hold.buffer || !shm || wl_shm_buffer_get_width(shm)!=o->width ||
        wl_shm_buffer_get_height(shm)!=o->height) return;
    t6_finish(client,manager);
    o->carrier=carrier;
    wl_resource_add_destroy_listener(carrier,&o->carrier_gone);
    wl_list_insert(&t6_pending,&o->link);
}
static void t6_retire(struct wl_client *client,struct wl_resource *manager,struct wl_resource *res)
{
    if (!wl_resource_instance_of(res,&wl_buffer_interface,&t6_buffer_impl)) return;
    struct t6_offer *o=wl_resource_get_user_data(res);
    t6_unlink(o);
    weston_buffer_reference(&o->hold,NULL,BUFFER_WILL_NOT_BE_ACCESSED);
}
static void t6_offer(struct wl_client *c,struct wl_resource *m,uint32_t id,
                     struct wl_resource *carrier,int fd,uint32_t opaque,uint32_t serial)
{
    import_offer(c,m,id,carrier,fd,opaque,serial,0,0);
}
static void prepare_target(struct wl_client *c,struct wl_resource *m,uint32_t id,
                           int fd,uint32_t width,uint32_t height,uint32_t serial)
{
    import_offer(c,m,id,NULL,fd,0,serial,width,height);
}
static void prepare_client(struct wl_client *c,struct wl_resource *m,uint32_t id,int fd,uint32_t serial)
{
    import_offer(c,m,id,NULL,fd,0,serial,1920,1048);
}
static const struct wd_texture_manager_v1_interface t6_impl = {t6_offer,t6_finish,t6_reuse,t6_retire,prepare_client,prepare_target,hold_carrier};
static void t6_bind(struct wl_client *c, void *data, uint32_t version, uint32_t id)
{
    struct wl_resource *r=wl_resource_create(c,&wd_texture_manager_v1_interface,version,id);
    if (r) wl_resource_set_implementation(r,&t6_impl,data,NULL);
    else wl_client_post_no_memory(c);
}
static struct wl_resource *t6_consume(struct wl_resource *carrier)
{
    struct t6_offer *o;
    struct wl_listener *hold=wl_resource_get_destroy_listener(carrier,remove_hold);
    if(hold) {remove_hold(hold,NULL); return NULL;}
    wl_list_for_each(o,&t6_pending,link) {
        if (o->carrier != carrier) continue;
        t6_unlink(o);
        static unsigned hits;
        if (++hits<=4 || hits%60==0) weston_log("T6 attach GPU buffer=%u hits=%u\n",wl_resource_get_id(o->resource),hits);
        return o->resource;
    }
    return carrier;
}
static const struct {struct wl_resource *(*consume)(struct wl_resource *);} t6_api={t6_consume};
static void t6_start(struct weston_compositor *ec)
{
    wl_list_init(&holds);
    wl_list_init(&t6_pending);
    if (weston_plugin_api_register(ec,"wd-texture-attach-v1",&t6_api,sizeof(t6_api))==0)
        t6_global=wl_global_create(ec->wl_display,&wd_texture_manager_v1_interface,3,ec,t6_bind);
}
static bool t6_fill(struct weston_compositor *ec, struct weston_buffer *b)
{
    struct t6_offer *o=wl_resource_get_user_data(b->resource);
    if (!o || !o->image) return false;
    struct gl_buffer_state *gb=zalloc(sizeof(*gb));
    if (!gb) return false;
    gb->gr=get_renderer(ec);
    gb->num_images=1;
    gb->images[0]=o->image;
    o->image=EGL_NO_IMAGE_KHR;
    gb->shader_variant=o->opaque ? SHADER_VARIANT_RGBX : SHADER_VARIANT_RGBA;
    b->width=o->width; b->height=o->height;
    b->buffer_origin=o->physical ? ORIGIN_TOP_LEFT : ORIGIN_BOTTOM_LEFT;
    b->format_modifier=DRM_FORMAT_MOD_INVALID;
    b->pixel_format=pixel_format_get_info(o->opaque ? DRM_FORMAT_XBGR8888 : DRM_FORMAT_ABGR8888);
    pixman_region32_init(&gb->texture_damage);
    ensure_textures(gb,GL_TEXTURE_2D,1);
    b->renderer_private=gb;
    gb->destroy_listener.notify=handle_buffer_destroy;
    wl_signal_add(&b->destroy_signal,&gb->destroy_listener);
    return true;
}
static void t6_paint(struct weston_buffer *b)
{
    if (!b->resource || !wl_resource_instance_of(b->resource,&wl_buffer_interface,&t6_buffer_impl)) return;
    struct t6_offer *o=wl_resource_get_user_data(b->resource);
    if (o->physical) {
        static unsigned client_paints;
        if (++client_paints<=8 || client_paints%60==0 || o->serial%30==0)
            weston_log("T8 physical GLES serial=%u buffer=%u paints=%u\n",
                      o->serial,wl_resource_get_id(b->resource),client_paints);
    }
    static unsigned paints;
    if (++paints<=6 || paints%60==0)
        weston_log("T6 GLES paint serial=%u buffer=%u paints=%u\n",o->serial,wl_resource_get_id(b->resource),paints);
}
